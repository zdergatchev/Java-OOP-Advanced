package Ferrari.models;

/**
 * Created by r3v3nan7 on 15.03.17.
 */
public interface Car {
    public String useBreaks();
    public String pushTheGas();

}
