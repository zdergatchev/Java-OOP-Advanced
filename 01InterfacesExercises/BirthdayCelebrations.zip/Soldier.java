package BorderControl_05;

/**
 * Created by Mihail on 3/15/2017.
 */
public interface Soldier {

    String getId();
}
