package BorderControl_05;

/**
 * Created by r3v3nan7 on 16.03.17.
 */
public interface BirthDate {

    public String getBirthDate();

}
