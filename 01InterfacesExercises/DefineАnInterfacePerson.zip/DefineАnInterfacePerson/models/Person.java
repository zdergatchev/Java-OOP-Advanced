package DefineАnInterfacePerson.models;


public interface Person {
    String name = null;
    int age = 0;

    public String getName();
    public int getAge();
}
