package ShapesDrawing;

public interface Drawable {
    void draw();
}
