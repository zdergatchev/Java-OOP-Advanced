package GenericFlatMethod;

/**
 * Created by r3v3nan7 on 16/03/2017.
 */
public class Main {
}
